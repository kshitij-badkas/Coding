#pragma once

int MakeSquare(int);
