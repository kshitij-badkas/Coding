#pragma once

int MakeCube(int);

