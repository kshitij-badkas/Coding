#define MYICON 101
