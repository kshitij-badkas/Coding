import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appCompSuccess]'
})
export class CompSuccessDirective 
{

  constructor(private ele: ElementRef) 
  { }

  setcolor(color: string)
  {
    this.ele.nativeElement.style.color = color;
  }

  @HostListener('mousemove') onMouseMove()
  {
    this.setcolor('green');
  }

  @HostListener('mouseleave') onmouseleave()
  {
    this.setcolor('black');
  }

}
