import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appCompFailure]'
})
export class CompFailureDirective 
{

  constructor(private ele: ElementRef) 
  { }

  setcolor(color: string)
  {
    this.ele.nativeElement.style.color = color;
  }

  @HostListener('mousemove') onMouseMove()
  {
    this.setcolor('red');
  }

  @HostListener('mouseleave') onmouseleave()
  {
    this.setcolor('black');
  }

}
