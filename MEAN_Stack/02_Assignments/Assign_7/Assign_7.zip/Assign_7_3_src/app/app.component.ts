import { Component, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  title = 'Assign_7';

  public str = "Marvellous Infosystems";

  public fun()
  {
    this.str = "Educating for better tommorrow";
  }
}
