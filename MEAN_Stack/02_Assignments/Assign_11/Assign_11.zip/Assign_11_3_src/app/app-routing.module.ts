import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BooksComponent } from './books/books.component';
import { InvalidPageComponent } from './invalid-page/invalid-page.component';
import { TechnologyComponent } from './technology/technology.component';

const routes: Routes = 
[
  { path: 'technology', component: TechnologyComponent },
  { path: 'books', component: BooksComponent },

  // default component
  { path: '', component: TechnologyComponent },
    
  // wild card component
  { path: '**', component: InvalidPageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
