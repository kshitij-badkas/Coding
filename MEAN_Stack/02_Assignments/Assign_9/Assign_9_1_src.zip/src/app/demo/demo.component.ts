import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';

@Component({
  selector: 'app-demo',
  template: `<h2> Inside Demo Component </h2>
              <li> Addition of 10 & 11 = {{ iRetAdd }} </li>
              <li> Subtraction of 10 & 11 = {{ iRetSub }} </li>`
})
export class DemoComponent implements OnInit 
{

  public iRetAdd: any;
  public iRetSub: any;

  constructor(private _obj: ArithmeticService) {}

  ngOnInit(): void 
  {
      this.iRetAdd = this._obj.Add();
      this.iRetSub = this._obj.Sub();
  }

}
