export interface IAddSub
{
    iValue1 : number,
    iValue2 : number
}