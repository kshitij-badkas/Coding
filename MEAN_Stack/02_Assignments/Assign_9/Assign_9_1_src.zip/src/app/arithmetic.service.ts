import { Injectable } from '@angular/core';
import { IAddSub } from './AddSub';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ArithmeticService 
{

  // private URL = 'assets/Data/Values.json'

  constructor(private _obj: HttpClient) { }

  public Add()
  {
      return (10 + 11);
  }

  public Sub()
  {
      return (10 - 11);
  }

}
