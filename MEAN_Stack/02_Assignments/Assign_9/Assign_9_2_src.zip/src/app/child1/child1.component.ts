import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  template: `<h2> Inside Child1 Component </h2>
              <h3> The Number {{iValue}} is Prime : {{ bRet }} </h3>`
})
export class Child1Component implements OnInit 
{
  public bRet: any; // boolean
  public iValue = 11;

  constructor(private _obj: NumberService) { }

  ngOnInit(): void 
  {
      this.bRet = this._obj.ChkPrime(this.iValue);
  }

}
