import { Component, OnInit } from '@angular/core';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child2',
  template: `<h2> Inside Child2 Component </h2>
            <h3> The string '{{ Str }}' contains : {{ iResult }} CAPITAL letters </h3>`
})
export class Child2Component implements OnInit 
{

  public iResult:number = 0;
  public Str = "JAY Ganesh ... Hello World!";

  constructor(private _obj: StringService) { }

  ngOnInit(): void 
  {
    this.iResult = this._obj.CountCapital(this.Str);
  }

}
