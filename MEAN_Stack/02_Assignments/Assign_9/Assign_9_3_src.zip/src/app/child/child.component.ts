import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child',
  template: `<h2> Inside Child Component </h2>
  <h3> The Number {{iValue}} is Prime : {{ bRet }} </h3>
  <h3> The string '{{ Str }}' contains : {{ iResult }} CAPITAL letters </h3>`
})
export class ChildComponent implements OnInit 
{

  public bRet: any;
  public iValue: number = 11;

  public iResult:number = 0;
  public Str = "JAY Ganesh ... Hello World!";

  constructor(private _obj1: NumberService, private _obj2: StringService) { }

  ngOnInit(): void 
  {
    this.bRet = this._obj1.ChkPrime(this.iValue);
    this.iResult = this._obj2.CountCapital(this.Str);
  }

}
