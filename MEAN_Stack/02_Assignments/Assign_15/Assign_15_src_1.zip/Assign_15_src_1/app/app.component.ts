import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{

  constructor(public fbobj:FormBuilder)
  {}

  ContactForm =this.fbobj.group(
  {
    firstName:['', [Validators.required, Validators.pattern(/[A-Za-z ]/) ]],
    phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/[0-9]/)]],
    email: ['', [Validators.required, Validators.pattern(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/)]],
    address: ['', [Validators.required, Validators.maxLength(30)]],

    /*city: ['', Validators.required],
    state: ['Maharashtra', 'Gujarat', 'UP'],
    zip: ['', Validators.maxLength(5)],
    comments:['', Validators.maxLength(30)]
    */

  }
  ); 

  title = 'Assign_15';
}
