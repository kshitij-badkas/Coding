import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.component.html',
  styleUrls: ['./new-comp.component.css']
})
export class NewCompComponent implements OnInit 
{

  Name: string = "KAB";

  Display():string
  {
    var str = "Infosystems";
    var result: string = this.Name + str;
    return (result);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
