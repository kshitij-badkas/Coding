import { style } from '@angular/animations';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<h1>Assignment 6 - 3</h1>
            <input type="text" value = "Marvellous Infosystems">`,
  styles: [`input { color:blue}`]
})
export class AppComponent {
  title = 'Assign_6';
}
