import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform 
{

  transform(value: number, param: string): string 
  {
    let result:string = "";
    var primeFlag: boolean = true;
    var perfectFlag: boolean = true;

    if(param == "Even")
    {
      if(value % 2 == 0)
      {
        result = "It is Even";
      }
      else
      {
        result = "It is NOT Even";
      }
    }
    else if(param == "Odd")
    {
      if(value % 2 != 0)
      {
        result = "It is Odd";
      }
      else
      {
        result = "It is NOT Odd";
      }
    }
    else if(param == "Prime")
    {
      for(var i = 2; i < (value / 2); i++)
      {
          if(value % i == 0)
          {
            primeFlag = false;
            break;
          }
          
      }
      if(primeFlag == false)
      {
        result = "It is NOT prime";
      }
      else
      {
        result = "It is Prime";
      }     
    }

    else if(param == "Perfect")
    {
      var factSum: number = 0;
      for(var i = 1; i < value; i++)
      {
          if(value % i == 0)
          {
            factSum = factSum + i;
          }          
      }
      if(factSum == value)
      {
        result = "It is Perfect";
      }
      else
      {
        result = "It is NOT Perfect";
      }
    }
    return (result);
  }

}
