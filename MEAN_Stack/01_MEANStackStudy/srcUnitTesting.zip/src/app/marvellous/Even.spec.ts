// import required function from .ts file
import { checkEven } from "./Even";

// Suit of test cases
describe('Check Even-Odd', () => {

    it('should return 1 if no. is Even', () => {
        const ret = checkEven(6);
        expect(ret).toBe(1);
    })

    it('should return 0 if no. is Odd', () => {
        const ret = checkEven(7);
        expect(ret).toBe(0);
    })
})

