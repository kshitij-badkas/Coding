import { HelloDirective } from './hello.directive';

describe('HelloDirective', () => {
  it('should create an instance', () => {
    const directive = new HelloDirective();
    expect(directive).toBeTruthy();
  });
});
