import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewPipeDemoPipe } from './new-pipe-demo.pipe';
import { HellocustomDirective } from './hellocustom.directive';

@NgModule({
  declarations: [
    AppComponent,
    NewPipeDemoPipe,
    HellocustomDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
