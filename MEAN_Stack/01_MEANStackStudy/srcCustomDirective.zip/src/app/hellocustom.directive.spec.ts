import { HellocustomDirective } from './hellocustom.directive';

describe('HellocustomDirective', () => {
  it('should create an instance', () => {
    const directive = new HellocustomDirective();
    expect(directive).toBeTruthy();
  });
});
