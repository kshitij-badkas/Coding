import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appHellocustom]'
})
export class HellocustomDirective {

  // Dependecny Injection
  constructor(private _eobj: ElementRef) { }

  @HostListener('mouseenter')onmouseenter()
  {
    this._eobj.nativeElement.style.background = 'red';
  }

  @HostListener('mouseleave')onmouseleave()
  {
    this._eobj.nativeElement.style.background = 'orange';
  }

}
