import { NewPipeDemoPipe } from './new-pipe-demo.pipe';

describe('NewPipeDemoPipe', () => {
  it('create an instance', () => {
    const pipe = new NewPipeDemoPipe();
    expect(pipe).toBeTruthy();
  });
});
