import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'newPipeDemo'
})
export class NewPipeDemoPipe implements PipeTransform 
{
  // <h1> {{ "Marvellous Pune" | newPipeDemo : "PPA" : "Python" : "Angular" }} </h1>
  
  // value -> Marvellous Pune , 
  // newPipeDemo -> @Pipe name, 
  // ...args -> "PPA" : "Python" : "Angular"

  transform(value: unknown, ...args: unknown[]): unknown 
  {

    /*
    var str : string = "";
    if(args[0] == "PPA")
    {
      str = "Batch starts 9th July" +value;
    }
    */
    let str = value;
    if(args[0] == "PPA")
    {
      str += " : Parat Parat Abhyas ...";
    }
    if(args[1] == "Python")
    {
      str += " : Artifical Intelligence ...";
    }
    if(args[2] == "Angular")
    {
      str += " : Full Stack ...";
    }
    

    return (str);
  }

}
