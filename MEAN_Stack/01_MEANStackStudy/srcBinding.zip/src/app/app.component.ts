import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  title = 'Binding';

  // from .ts to .html
  iCnt : any = 11;
  testString: string = "Test - " + this.iCnt;
  
  // from .html to .ts
  dataFromHtml : any;

  // EventListner for button of .html ---> Send Data from .html to .ts
  SendData(value : any)
  {
    this.dataFromHtml = value;
    console.log("Data from .html to .ts is ::: "+this.dataFromHtml);
  }
}
