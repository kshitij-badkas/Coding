import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous',
  templateUrl: './marvellous.component.html',
  styleUrls: ['./marvellous.component.css']
})
export class MarvellousComponent implements OnInit
{
  // characteristics
  
  // public batches = ["PPA", "LB", "AWD", "PML", "LSP", "C#"];

  public batches = ["PPA", "LB", "AWD", "PML", "LSP", "C#"];

  // Array object
  // batches : string[] = new Array("PPA", "LB", "AWD", "PML", "LSP", "C#");

  // behaviours  
  ngOnInit()
  {}

}
