import { Injectable } from '@angular/core';

// Dependancy Injection -----> TO GHUSNAR AHE - TYACHYAT KONI GHUSNAR NAHI.
@Injectable({
  providedIn: 'root'
})
export class BatchServiceService 
{
  constructor() { }

  // 
  GetBatchDetails()
  {
    /*************************************
     * !!! unreachable code - it is treated as `return ;` due to a space or \n after 'return'
     
      return 
      [       // unreachable code
        { },  // unreachable code
        { },  // unreachable code
        { }   // unreachable code
      ];      // unreachable code
    **************************************/

    // correct syntax 
    return [
            {"Name":"PPA", "Fees":9000, "Duration":"4 Months"},
            {"Name":"LB", "Fees":7500, "Duration":"4 Months"},
            {"Name":"WEB", "Fees":2500, "Duration":"3 Months"},
            {"Name":"Project", "Fees":4000, "Duration":"3 Months"}
    ];
  }
}
