import { Component, OnInit } from '@angular/core';
import { BatchServiceService } from '../batch-service.service';

@Component({
  selector: 'app-batch-list',
  template: `<h2>Inside BatchList Component</h2>
            <ul *ngFor = "let MyValue of Batches">
              <li> {{ MyValue.Name }} </li>
            </ul>`
})
export class BatchListComponent implements OnInit 
{

  // characteristics
  public Batches : any = [];

  // composition
  constructor(private _batchServiceOBJ : BatchServiceService) { }

  // Pahila Shwaas of any Component - pahila; so ekdach run hoto
  ngOnInit(): void 
  {
    this.Batches = this._batchServiceOBJ.GetBatchDetails();
  }

}
