import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ademo',
  templateUrl: './ademo.component.html',
  styleUrls: ['./ademo.component.css']
})
export class ADemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
