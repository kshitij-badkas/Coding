import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent
{
  // characterisitics
  name : string = "Kshitij";
  no1 : number = 51;
  no2 : number = 55;

  // behaviour
/*  constructor @Inject(a : number, b : number)
  {
    this.no1 = a;
    this.no2 = b;
  }
*/
  display() : string
  {
    var ret : string = "Hello "+this.name;
    return (ret);
  }

  addition(no1 : number, no2 : number) : number
  {
    var ret = no1 + no2; // {{addition(10, 11)}} => 21
    // var ret = this.no1 + this.no2;  // 106
    return (ret);
  }
}

