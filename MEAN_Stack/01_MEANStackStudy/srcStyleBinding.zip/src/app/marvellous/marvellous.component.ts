import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous',
  templateUrl: './marvellous.component.html',
  styleUrls: ['./marvellous.component.css']
})
export class MarvellousComponent implements OnInit {

  // characterstics
  public MyColor = "Orange";
  public veg : boolean = true;

  // behaviours
  constructor() { }

  public foodType(data : any)
  {
    if(this.veg === true)
    {
      this.veg = false
    }
    else if(this.veg === false)
    {
      this.veg = true;
    }

  }


  ngOnInit(): void {
  }

}
