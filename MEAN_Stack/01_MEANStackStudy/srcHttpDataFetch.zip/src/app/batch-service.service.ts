import { Injectable } from '@angular/core';
// import Interface IBatches
import { IBatches } from './Batches';
// import Observable
import { Observable } from 'rxjs';
// import HttpClient
import { HttpClient } from '@angular/common/http'

// Dependancy Injection -----> TO GHUSNAR AHE - TYACHYAT KONI GHUSNAR NAHI.
@Injectable({
  providedIn: 'root'
})
export class BatchServiceService 
{
  constructor(private _obj:HttpClient) 
  { }

  private _url : string = "/assets/Data/Batches.json";

  GetBatchDetails():Observable<IBatches[]>
  {
    return this._obj.get <IBatches[]> (this._url);
  }
}
