import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { BatchDetailsComponent } from './batch-details/batch-details.component';
import { BatchListComponent } from './batch-list/batch-list.component';
import { BatchServiceService } from './batch-service.service';  // importing BatchServiceService

// import HttpClientModule
import { HttpClientModule } from '@angular/common/http'
@NgModule({
  declarations: [
    AppComponent,
    BatchDetailsComponent,
    BatchListComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule    // add Module to 'imports' array
  ],
  providers: [BatchServiceService],   // service name is 'BatchServiceService'
  bootstrap: [AppComponent]
})
export class AppModule { }

// Note : 

/*

  Service - It is class with specific purpose.
  
  We can use service to share data between components
  and to implement application logic, External interaction 
  like database connections. 

*/
