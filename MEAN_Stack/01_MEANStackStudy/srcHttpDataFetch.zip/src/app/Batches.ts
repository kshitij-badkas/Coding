export interface IBatches
{
    Name : String,
    Fees : Number,
    Duration : Number
}
