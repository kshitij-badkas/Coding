INSIDE PROJECT - 

ng build  : ---- creates 'dist' folder  :::::::::(ng build --aot --prod)::::::::::

ProjectFolder > dist > projectnamefolder 

upload 'projectnamefolder' in S3 bucket.

'Add Files' - all files except 'assets' folder because there are no assets currently.


************************


After upload -->

Properties
1. Bucket properties > Static website hosting ( click Edit)
2. Keep everything default ---> Index Document > index.html (enter manually)

Permissions
1. Bucket permissions > Bucket policy (click Edit)
2. Policy Examples > COPY-PASTE

********
"Resource": "arn:aws:s3:::BUCKET_NAME/*"
********

{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "PublicRead",
            "Effect": "Allow",
            "Principal": "*",
            "Action": [
                "s3:GetObject",
                "s3:GetObjectVersion"
            ],
            "Resource": "arn:aws:s3:::BUCKET_NAME/*"
        }
    ]
}

==================================================
DO NOT USE BELOW
==================================================

/* 
{
	"Version": "2012-10-17",
	"Statement": [
		{
			"Sid": "AddPublicReadCannedAcl",
			"Effect": "Allow",
			"Principal": "*",
			"Action": [
				"s3:PutObject",
				"s3:PutObjectAcl"
			],
			"Resource": "arn:aws:s3:::angkbrevision/*",
			"Condition": {
				"StringEquals": {
					"s3:x-amz-acl": "public-read"
				}
			}
		}
	]
}
*/

