import { Component, OnInit } from '@angular/core';
import { ViewChild, ElementRef, ViewChildren, QueryList } from '@angular/core';

@Component({
  selector: 'app-marvellous',
  templateUrl: './marvellous.component.html'
})
export class MarvellousComponent
{
  @ViewChild("myref") myValue !:ElementRef;

  ngAfterViewInit()
  {
    console.log("Inside ngAfterViewInit() ()");
    console.log(this.myValue);
    console.log("Inside ngAfterViewInit() ");
    this.myValue.nativeElement.focus()
  }
}