import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { ADemoComponent } from './ademo/ademo.component';


@NgModule({
  declarations: [
    ADemoComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule
  ],
  
  // Add exports array 
  exports: [
    ADemoComponent
  ]
})
export class AdminModule { }
