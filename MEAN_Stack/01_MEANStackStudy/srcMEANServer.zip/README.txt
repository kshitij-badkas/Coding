CLIENT AND SERVER
----------------------------------

Inside MEANProjectNameFolder -> 
create 'Server' folder.
	MEANProjectNameFolder\Server >

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Inside MEANProjectNameFolder -> 
Create new angular project 'client'
	ng new client
	
	
TO RUN THE CLIENT : INSIDE CLIENT FOLDER ---- ng serve --proxy-config proxy.conf.json 
(proxy.conf.json FILE SHOULD BE CREATED FIRST)
{
    "/api/*": {
      "target": "http://localhost:3000",
      "secure": false,
      "pathRewrite": {
        "^/api": ""
      }
    }
}



In Server folder ->

	npm init --yes

	npm install express body-parser --yes    -> 'node_modules' is created
	https://expressjs.com/ - ($ npm install express --save)

	Create 'app.js' ---> SERVER CODE HERE

TO RUN : NEED TO RUN AFTER EVERY CHANGE MADE TO CODE

	node app.js 
	
	*****
	nodemon app.js
	*****

ON BROWSER : 

	http://localhost:5100 
	http://localhost:5100/getBatches



