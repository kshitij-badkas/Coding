// get function handler (`const express` is now a handler.)
const express = require("express");
eobj = express();
port = 3000;

// callback
function MarvellousConnect(request, response)
{
    console.log("Hello from Marvellous. Marvellous Server is LIVE @port 3000");
}
eobj.listen(port, MarvellousConnect);

// callback
function MarvellousRoot(request, response)
{
    response.json({ 'Status':'Success' });
}
eobj.get('/', MarvellousRoot);

// callback
function MarvellousBatches(request, response)
{
    response.json({ "Python":"3 months" ,"PPA":"4 months", "Angular":"5 months" });
}
eobj.get('/getBatches', MarvellousBatches);

// callback
function MarvellousContact(req, res)
{
    res.json({ "Mobile":"91919191991", "website":"www.sitedot.com" });
}
eobj.get('/getContact', MarvellousContact);

// FAT-ARROW
eobj.get('/Demo', (req, res) => {
    res.json({ 
        "Data" : "FAt Arrow Demo"
     });
});