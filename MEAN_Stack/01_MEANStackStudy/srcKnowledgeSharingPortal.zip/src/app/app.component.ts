import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent 
{
  loadedFeature = 'project';

  // onNavigate(feature: string)
  onNavigate(feature: any)  // TEMPORARY FIX - DO NOT USE 'any' everytime.
  {
    this.loadedFeature = feature;
  }
}
