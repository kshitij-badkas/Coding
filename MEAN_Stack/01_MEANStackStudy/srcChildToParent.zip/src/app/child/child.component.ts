import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent 
{
  // <!-- STEP 3 -->
  @Output() public MyEvent = new EventEmitter();

  public messageFromChild = "Hello Parent...";

  // <!-- STEP 2 -->
  public SendMessage()
  {
    this.MyEvent.emit(this.messageFromChild);
  }
}
