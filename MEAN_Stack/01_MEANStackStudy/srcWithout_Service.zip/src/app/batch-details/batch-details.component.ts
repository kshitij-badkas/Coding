import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch-details',
  template: `<h2>Inside BatchDetails Component</h2>
              <h3>Batch Names : </h3>
              <ul *ngFor = "let value of Batches"> 
                <li> {{ value.Name }} </li>
              </ul>`  // <--- Inline Template
})
export class BatchDetailsComponent implements OnInit 
{

  public Batches = [
                    { "Name" : "PPA", "Duration" : "3 Months", "Fees" : 10000 },
                    { "Name" : "LB", "Duration" : "3.5 Months", "Fees" : 15000 },
                    { "Name" : "AWD", "Duration" : "4 Months", "Fees" : 17000 }
                    ];

  constructor() { }

  ngOnInit(): void {
  }

}
