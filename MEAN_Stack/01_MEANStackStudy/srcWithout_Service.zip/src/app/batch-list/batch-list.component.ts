import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch-list',
  template: `<h2>Inside BatchList Component</h2>
              <h3>Batch Names With Duration : </h3>
              <ul *ngFor = "let MyValue of Batches">
              <li> {{ MyValue.Name }} -- {{ MyValue.Duration }} </li>
              </ul>`   // <--- Inline Template
})
export class BatchListComponent implements OnInit 
{

  public Batches = [
                    { "Name" : "PPA", "Duration" : "3 Months", "Fees" : 10000 },
                    { "Name" : "LB", "Duration" : "3.5 Months", "Fees" : 15000 },
                    { "Name" : "AWD", "Duration" : "4 Months", "Fees" : 17000 }
                    ];

  constructor() { }

  ngOnInit(): void {
  }

}
