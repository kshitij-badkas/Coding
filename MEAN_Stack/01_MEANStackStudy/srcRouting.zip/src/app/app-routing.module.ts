import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import components
import { BatchesComponent } from './batches/batches.component';
import { SubjectsComponent } from './subjects/subjects.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { InvalidComponent } from './invalid/invalid.component';

//const varName : Type
const routes: Routes = [
  { path : 'batches', component : BatchesComponent },
  { path : 'subjects', component : SubjectsComponent },
  { path : 'aboutus', component : AboutUsComponent },
  // default path
  { path : '', component : AboutUsComponent },
  // wildcard route
  { path : '**', component : InvalidComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
