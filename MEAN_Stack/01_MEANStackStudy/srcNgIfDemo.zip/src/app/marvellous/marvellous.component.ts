import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous',
  templateUrl: './marvellous.component.html',
  styleUrls: ['./marvellous.component.css']
})
export class MarvellousComponent 
{
  flag : boolean = true;
  food : boolean = false;
  DivTagFlag : boolean = false;
}
