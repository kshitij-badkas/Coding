import { Component } from '@angular/core';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})

export class EventComponent
{
  // characteristics
  iCnt : number = 1;
  str : string = "";

  // behaviour
  public eventHandler()
  {
    var clickCount = this.iCnt++;
    console.log("Inside eventHandler()" + clickCount);
  }

  public Hello()
  {
    this.str = "Hello Button is clicked. Hello() called";
  }

  public Marvellous(data : any)
  {
    console.log("Marvellous(data) : EventObject ===> "+data);
  }

}
