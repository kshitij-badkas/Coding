import { Component, Input, OnInit } from '@angular/core';

import { IBook } from '../../models/ibook';
import { BookService } from 'src/app/services/book.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit 
{

  @Input() viewMode = false;

  @Input() currentBook: IBook = 
  {
    title: "",
    author: "",
    favourite: false
  };

  message = "";

  constructor(private bookService: BookService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void 
  { 
    
    console.log("INSIDE book-details component - ngOnInit() -> viewMode : ",this.viewMode);
    if(!this.viewMode)
    {
      console.log("INSIDE book-details component - ngOnInit() -> if block {}");

      this.message = "";
      this.getBook(this.route.snapshot.params['id']);
    }
    console.log("INSIDE book-details component - ngOnInit() -> OUTSIDE if block {}");
    



    //this.message = "";
    //this.getBook(this.route.snapshot.params['id']);
  
  }

  // get Book by id
  getBook(id: string): void
  {
    this.bookService.get(id).subscribe({
      next: (data) => {
        this.currentBook = data;
        console.log("INSIDE book-details component - getBook()");
        console.log(data);
      },
      error: (e) => console.error(e)
    });
  }

  // update Book by id
  updateBook(): void
  {
    this.message = "";

    this.bookService.update(this.currentBook.id, this.currentBook).subscribe({
      next: (res) => {
        console.log(res);
        this.message = res.message ? res.message : 'This book was updated successfully!'; 
      },
      error: (e) => console.log(e)
    });
  }

  // delete Book by id
  deleteBook(): void
  {
    this.bookService.delete(this.currentBook.id).subscribe({
      next: (res) => {
        console.log(res);
        this.router.navigate(['/books']);
      },
      error: (e) => console.log(e)
    });
  }

  // update favourite books
  updateFavourite(status: boolean): void 
  {
    const data = 
    {
      title: this.currentBook.title,
      author: this.currentBook.author,
      favourite: status
    };

    this.message = "";

    this.bookService.update(this.currentBook.id, data).subscribe({
        next: (res) => {
          console.log(res);
          this.currentBook.favourite = status;
          this.message = res.message ? res.message : 'The status was updated successfully!';
        },
        error: (e) => console.error(e)
      });
  }

}
