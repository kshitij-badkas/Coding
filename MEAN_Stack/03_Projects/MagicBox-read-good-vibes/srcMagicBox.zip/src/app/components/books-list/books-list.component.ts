import { Component, OnInit } from '@angular/core';

import { BookService } from 'src/app/services/book.service';
import { IBook } from '../../models/ibook';


@Component({
  selector: 'app-books-list',
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.css']
})
export class BooksListComponent implements OnInit 
{

  books?: IBook[];
  currentBook: IBook = {};
  currentIndex = -1;
  title = '';
  author ='';

  constructor(private bookService: BookService) { }

  ngOnInit(): void 
  {
    this.retrieveAllBooks();
  }

  // get all Books
  retrieveAllBooks(): void
  {
    this.bookService.getAll().subscribe({
      next: (data) => {
        this.books = data;
        console.log(data);
      },
      error: (e) => console.error(e)
    });
  }

  refreshList(): void 
  {
    this.retrieveAllBooks();
    this.currentBook = {};
    this.currentIndex = -1;
  }

  setActiveBook(book: IBook, index: number): void 
  {
    this.currentBook = book;
    this.currentIndex = index;
  }

  // delete all Books
  removeAllBooks(): void
  {
    this.bookService.deleteAll().subscribe({
      next: (res) => {
        console.log(res);
        this.refreshList();
      },
      error: (e) => console.error(e)
    });
  }

  // get Books by title
  searchTitle(): void
  {
    this.currentBook = {};
    this.currentIndex = -1;

    this.bookService.findByTitle(this.title).subscribe({
      next: (data) => {
        this.books = data;
        console.log(data);
      },
      error: (e) => console.error(e)
    });
  }

  /*
  // get Favourite Books
  getFavouriteBooks(id: string): void
  {
    this.bookService.getFavourite(id).subscribe({
      next: (data) => {
        this.currentBook.favourite = data;
        console.log("INSIDE book-details component - getFavouriteBooks()");
        console.log(data);
      },
      error: (e) => console.error(e)
    });
  }
*/

  // get Books by author
  searchAuthor(): void
  {
    this.currentBook = {};
    this.currentIndex = -1;

    this.bookService.findByAuthor(this.author).subscribe({
      next: (data) => {
        this.books = data;
        console.log(data);
      },
      error: (e) => console.error(e)
    });
  }

}

