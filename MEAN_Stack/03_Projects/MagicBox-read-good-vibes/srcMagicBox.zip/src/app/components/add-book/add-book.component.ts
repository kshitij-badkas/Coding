import { Component, OnInit } from '@angular/core';

import { BookService } from 'src/app/services/book.service';
import { IBook } from '../../models/ibook';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit 
{

  book: IBook = 
  {
    title: "",
    author: "",
    favourite: false
  };
  saved = false;

  constructor(private bookService: BookService) {}

  ngOnInit(): void 
  {}

  // create
  saveBook(): void
  {
    const data = 
    {
      title: this.book.title,
      author: this.book.author
    };
  
    this.bookService.create(data).subscribe({
      next: (res) => {
        console.log(res);   // we pass 'res' beacuse we want to `console.log()` it.
        this.saved = true;
      },
      error: (e) => console.error(e)
    });
  }

  newBook(): void
  {
    this.saved = false;
    this.book = 
    {
      title: "",
      author: "",
      favourite: false
    }; 
  }

}
