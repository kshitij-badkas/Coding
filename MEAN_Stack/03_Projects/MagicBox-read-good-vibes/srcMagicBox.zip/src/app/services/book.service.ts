import { Injectable } from '@angular/core';

import { IBook } from '../models/ibook';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const baseUrl = "http://localhost:4000/api/books";

@Injectable({
  providedIn: 'root'
})
export class BookService 
{
  constructor(private http: HttpClient) { }

  // get all Books
  getAll(): Observable<IBook[]>
  {
    return this.http.get<IBook[]>(baseUrl);
  }

  // get single Book by id
  get(id: any): Observable<IBook>
  {
    return this.http.get(`${baseUrl}/${id}`);
  }

  // get favourite Books by id
  getFavourite(id: any): Observable<IBook>
  {
    return this.http.get(`${baseUrl}/${id}`);
  }

  // get Books by title
  findByTitle(title: any): Observable<IBook[]>
  {
    return this.http.get<IBook[]>(`${baseUrl}?title=${title}`);
  }

  // get Books by author
  findByAuthor(author: any): Observable<IBook[]>
  {
    return this.http.get<IBook[]>(`${baseUrl}?author=${author}`);
  }

  //create a Book
  create(data: any): Observable<any>
  {
    return this.http.post(baseUrl, data);
  }

  //update a Book by id
  update(id: any, data: any): Observable<any>
  {
    return this.http.put(`${baseUrl}/${id}`, data);
  }

  // delete single Book by id
  delete(id: any): Observable<any>
  {
    return this.http.delete(`${baseUrl}/${id}`);
  }

  // delete all Books
  deleteAll(): Observable<any>
  {
    return this.http.delete(baseUrl);
  }
}
