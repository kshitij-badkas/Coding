export interface IBook 
{
    id?: any;
    title?: string;
    author?: string;
    favourite?: boolean;
}
