const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());

// parse requests of content-type - application/json
app.use(express.json());


const db = require("./app/models");
    db.mongoose.connect(db.url).then(() => {
      console.log("Database Connection : SUCCESS!");
    }).catch(err => {
      console.log("ERROR - Database Connection : FAILED!", err);
      process.exit();
    });

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to The Magic Box application." });
});

require("./app/routes/book.routes")(app);

// set port, listen for requests
const PORT = 4000;
app.listen(PORT, () => { 
  console.log(`Server is running on port ${PORT}.`);
  console.log("Welcome to The Magic Box application."); 
});
