module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
        title: String,
        author: String,
        favourite: Boolean
      },
      { timestamps: true }
    );

     // '_id' to 'id' --> option 1
    schema.set('toJSON', {
      virtuals: true,
    });

    /*
    // '_id' to 'id ---> option 2
    schema.set('toJSON', {
      virtuals: true,
      versionKey:false,
      transform: function (doc, ret) 
      {   
        delete ret._id  
      }
    });
    */
    
    const Book = mongoose.model("book", schema);
    return Book;
};
