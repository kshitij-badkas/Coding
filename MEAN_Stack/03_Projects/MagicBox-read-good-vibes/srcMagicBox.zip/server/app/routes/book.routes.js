module.exports = app => {
    // const books = require("../controllers/book.controller");
    const books = require("../controllers/book.controller.js");

    var router = require("express").Router();

    // Create a new Book
    router.post("/", books.create);

    // Get all Books
    router.get("/", books.findAll);

    // Get all favourite Books
    router.get("/favourites", books.findAllFavourite);

    // Get a single Book with id
    router.get("/:id", books.findById);

    // Update a Book with id
    router.put("/:id", books.update);

    // Delete a Book with id
    router.delete("/:id", books.delete);

    // Delete all Books
    router.delete("/", books.deleteAll);

    app.use("/api/books", router);

};
