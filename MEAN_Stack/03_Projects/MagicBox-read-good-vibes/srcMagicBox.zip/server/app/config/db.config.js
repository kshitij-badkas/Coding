module.exports = { 
  url: "mongodb+srv://url-here" 
};
