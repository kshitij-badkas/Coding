// ********** npm install express-jwt@5.3.1
const expressJwt = require('express-jwt');
const userService = require('./users/user.service');
const secretKey = require('./secret.json');

module.exports = jwt;

function jwt() 
{
    const secret = secretKey.secret;
    
    return expressJwt({ secret, algorithms: ['HS256'], isRevoked }).unless({
        path: [
            '/users/authenticate',
            '/users/register'
        ]
    });
    
}


async function isRevoked(req, payload, done) 
{
    const user = await userService.getById(payload.sub);

    if (!user) 
    {
        return done(null, true);
    }

    done();
};
