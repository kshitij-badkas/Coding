const mongoose = require('mongoose');

// connect to DB
mongoose.connect("mongodb+srv://<user>:<pass>@cluster0.p47tvup.mongodb.net/?retryWrites=true&w=majority");
mongoose.Promise = global.Promise;
// Export Object of user model - to be used for user service
module.exports = { User: require('./users/user.model') };

