import React, { Component } from "react";

import BookDataService from "../services/book.service";
import { withRouter } from '../common/with-router';

class BookDetails extends Component
{
    constructor(props)
    {
        super(props);
        this.onChangeTitle = this.onChangeTitle.bind(this);
        this.onChangeAuthor = this.onChangeAuthor.bind(this);
        this.getBook = this.getBook.bind(this);
        this.updateFavourite = this.updateFavourite.bind(this);
        this.updateBook = this.updateBook.bind(this);
        this.deleteBook = this.deleteBook.bind(this);

        this.state =
        {
            currentBook: {
                id: null,
                title: "",
                author: "", 
                favourite: false,
            },
            message: ""
        };
    }

    componentDidMount()
    {
        this.getBook(this.props.router.params.id);
    }

    onChangeTitle(e) 
    {
        const title = e.target.value;
    
        this.setState(function(prevState) 
        {
          return {
            currentBook: {
              ...prevState.currentBook,
              title: title
            }
          };
        });
      }
    
    onChangeAuthor(e) 
    {
        const author = e.target.value;
        
        this.setState(prevState => ({
            currentBook: {
            ...prevState.currentBook,
            author: author
            }
        }));
    }

    getBook(id) 
    {
        BookDataService.get(id).then(response => {
            this.setState({
                currentBook: response.data
            });
            console.log(response.data);
            }).catch(e => {
            console.log(e);
            });
    }

    updateFavourite(status) 
    {
        var data = {
            id: this.state.currentBook.id,
            title: this.state.currentBook.title,
            author: this.state.currentBook.author,
            favourite: status
        };

        BookDataService.update(this.state.currentBook.id, data).then(response => {
            this.setState(prevState => ({
                currentBook: {
                ...prevState.currentBook,
                favourite: status
                }
            }));
            console.log(response.data);
            })
            .catch(e => {
            console.log(e);
            });
    }

    updateBook() 
    {
        BookDataService.update(
            this.state.currentBook.id, 
            this.state.currentBook
            ).then(response => {
            console.log(response.data);
            this.setState({
                message: "The Book was updated successfully!"
            });
            }).catch(e => {
                console.log(e);
            });
    }

    deleteBook() 
    {    
        BookDataService.delete(this.state.currentBook.id).then(response => {
            console.log(response.data);
            this.props.router.navigate('/books');
            }).catch(e => {
            console.log(e);
            });
    }

    render() {
        const { currentBook } = this.state;

        return (
        <div>
            {currentBook ? (
            <div className="edit-form">
                <h4>Book Details</h4>
                <form>
                <div className="form-group">
                    <label htmlFor="title">Title</label>
                    <input
                    type="text"
                    className="form-control"
                    id="title"
                    value={currentBook.title}
                    onChange={this.onChangeTitle}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="description">Author</label>
                    <input
                    type="text"
                    className="form-control"
                    id="description"
                    value={currentBook.author}
                    onChange={this.onChangeAuthor}
                    />
                </div>

                <div className="form-group">
                    <label>
                    </label>
                    <strong>{currentBook.favourite ? "Favourite" : ""}</strong>
                </div>
                </form>

                {currentBook.favourite ? (
                <button
                    className="btn btn-primary mr-2"
                    onClick={() => this.updateFavourite(false)}
                >
                    Un-Favourite
                </button>
                ) : (
                <button
                    className="btn btn-primary mr-2"
                    onClick={() => this.updateFavourite(true)}
                >
                    Favourite
                </button>
                )}

                <button
                className="btn btn-danger mr-2"
                onClick={this.deleteBook}
                >
                Delete
                </button>

                <button
                type="submit"
                className="btn btn-success mr-2"
                onClick={this.updateBook}
                >
                Update
                </button>
                <p>{this.state.message}</p>
            </div>
            ) : (
            <div>
                <br />
                <p>Please click on a Book for more...</p>
            </div>
            )}
        </div>
        );
    }

}

export default withRouter(BookDetails);
