// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = 
{
  production: false,
  firebase: 
  {
    apiKey: "AIzaSyC5nzvPloCrigVY3TRlST9SBSOrZO7QnYU",
    authDomain: "noteworthy-9a676.firebaseapp.com",
    projectId: "noteworthy-9a676",
    storageBucket: "noteworthy-9a676.appspot.com",
    messagingSenderId: "229874213185",
    appId: "1:229874213185:web:319a8e32e106eb0f9a41c0",
    measurementId: "G-QCTDJ7XKVS"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
