export class Notes 
{
    id?: string;
    title?: string;
    description?: string;
    bookmark?: boolean;
}
