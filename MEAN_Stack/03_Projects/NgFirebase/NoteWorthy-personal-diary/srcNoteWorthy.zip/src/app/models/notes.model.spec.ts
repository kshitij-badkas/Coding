import { Notes } from './notes.model';

describe('Notes', () => {
  it('should create an instance', () => {
    expect(new Notes()).toBeTruthy();
  });
});
