import { Component, OnInit } from '@angular/core';

import { NotesService } from 'src/app/services/notes.service';
import { map } from 'rxjs';
import { Notes } from 'src/app/models/notes.model';

@Component({
  selector: 'app-notes-list',
  templateUrl: './notes-list.component.html',
  styleUrls: ['./notes-list.component.css']
})
export class NotesListComponent implements OnInit 
{

  notes ?: Notes[];
  currentNote ?: Notes;
  currentIndex = -1;
  title = "";

  constructor(private notesService: NotesService) { }

  ngOnInit(): void 
  {
    this.retrieveNotes();
  }

  refreshList(): void
  {
    this.currentNote = undefined;
    this.currentIndex = -1;
    this.retrieveNotes();
  }

  retrieveNotes(): void
  {
    this.notesService.getAll().snapshotChanges().pipe(
      map(changes =>
         changes.map( c => 
          ({ id: c.payload.doc.id, ...c.payload.doc.data() })
            )
          )
        ).subscribe(data => {
              this.notes = data;
      });
  }

  setActiveNote(note: Notes, index: number): void
  {
    this.currentNote = note;
    this.currentIndex = index;
  }

}
