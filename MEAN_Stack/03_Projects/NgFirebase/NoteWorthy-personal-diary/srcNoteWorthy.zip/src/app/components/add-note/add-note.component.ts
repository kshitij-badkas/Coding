import { Component, OnInit } from '@angular/core';

import { Notes } from 'src/app/models/notes.model';
import { NotesService } from 'src/app/services/notes.service';

@Component({
  selector: 'app-add-note',
  templateUrl: './add-note.component.html',
  styleUrls: ['./add-note.component.css']
})
export class AddNoteComponent implements OnInit 
{
  note: Notes = new Notes();
  saved = false;

  constructor(private notesService: NotesService) { }
  
  ngOnInit(): void { }

  newNote(): void
  {
    this.saved = false;
    this.note = new Notes();
  }

  saveNote(): void
  {
    this.notesService.create(this.note).then(() => {
      console.log("Created new item. saveNote() : SUCCESS");
      this.saved = true;
    });
  }

}
