import { Component, OnInit } from '@angular/core';

import { Input, Output, OnChanges, EventEmitter } from '@angular/core';
import { Notes } from 'src/app/models/notes.model';
import { NotesService } from 'src/app/services/notes.service';

@Component({
  selector: 'app-note-details',
  templateUrl: './note-details.component.html',
  styleUrls: ['./note-details.component.css']
})

export class NoteDetailsComponent implements OnInit 
{

  @Input() note?: Notes;
  @Output() refreshList: EventEmitter<any> = new EventEmitter();
  currentNote: Notes = {
    title: "",
    description: "",
    bookmark: false
  };
  message = "";

  constructor(private notesService: NotesService) { }

  ngOnInit(): void 
  {
    this.message = "";
  }

  ngOnChanges(): void
  {
    this.message = "";
    this.currentNote = {...this.note};
  }

  updateBookmark(status: boolean): void 
  {
    if (this.currentNote.id) {
      this.notesService.update(this.currentNote.id, { bookmark: status })
      .then(() => {
        this.currentNote.bookmark = status;
        this.message = 'The bookmark was updated successfully!';
      })
      .catch(err => console.log(err));
    }
  }

  updateNote(): void 
  {
    const data = {
      title: this.currentNote.title,
      description: this.currentNote.description
    };

    if (this.currentNote.id) 
    {
      this.notesService.update(this.currentNote.id, data)
        .then(() => this.message = 'The note is updated successfully!')
        .catch(err => console.log(err));
    }
  }

  deleteNote(): void 
  {
    if (this.currentNote.id) {
      this.notesService.delete(this.currentNote.id)
        .then(() => {
          this.refreshList.emit();
        })
        .catch(err => console.log(err));
    }
  }

}
