import { Injectable } from '@angular/core';

import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/compat/firestore';
import { Notes } from '../models/notes.model';

@Injectable({
  providedIn: 'root'
})
export class NotesService 
{
  // database path
  private dbPath = '/notes';

  notesRef!: AngularFirestoreCollection<Notes>;

  constructor(db: AngularFirestore) 
  { 
    this.notesRef = db.collection(this.dbPath);
  }

  // read all notes
  getAll(): AngularFirestoreCollection<Notes>
  {
    return (this.notesRef);
  }

  // create a note
  create(note: Notes): any
  {
    return (this.notesRef.add({ ...note }));  // Adding documents to a collection
  }

  // update a note
  update(id: string, data: any): Promise<void>
  {
    return (this.notesRef.doc(id).update(data));
  }
  
  // delete a note
  delete(id: string): Promise<void>
  {
    return (this.notesRef.doc(id).delete());
  }

}

