import { Component } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { AngularFirestore } from '@angular/fire/compat/firestore';

import { Observable, async, asyncScheduler} from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  public items!: Observable<any[]>;
  
  // FETCH PRICES
  public requestOptions !: any;
  public URL !: string ;
  public APIkey !: string;
  public apiResult !: Observable<any[]>;
  
    constructor(db: AngularFirestore) {
        // this.items = db.collection('/batches').valueChanges() as any;

        this.items = db.collection('/metals').valueChanges() as any;

        this.URL = "https://api.metalpriceapi.com/v1/latest?api_key=";
        this.APIkey = "83b6dbc83079ad8b49b78dd4f1c9cc6c";
        
        this.requestOptions =
        {
          method: 'GET',
          redirect: 'follow',
        };
              
        // get data from collection     
        let dbCollection = db.collection('metals');
        console.log("DATA FROM COLLECTION : ");
        dbCollection.snapshotChanges().forEach(doc => {
          console.log(doc);
        });
      

        // XAU - Gold
        // XAG - Silver
        fetch(`${this.URL}${this.APIkey}&base=INR&currencies=XAU,XAG`, this.requestOptions)
        .then(response => response.json())
        .then(result => console.log(result))
        .catch(error => console.log('error', error));
      
    }
}
